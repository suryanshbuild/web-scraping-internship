# Book Data Scraper — Internship Task 1

A beginner-friendly Python web scraping project using Requests, BeautifulSoup, and CSV.
It collects book title, price, availability, star rating, and product URL from the
practice website https://books.toscrape.com/.

## Requirements
- Python 3.9+
- Internet connection

## Setup
```bash
python -m venv .venv
```
Activate the environment:
- Windows: `.venv\\Scripts\\activate`
- macOS/Linux: `source .venv/bin/activate`

Install dependencies:
```bash
pip install -r requirements.txt
```

## Run
Scrape the first 3 pages:
```bash
python scraper.py --pages 3 --output books_dataset.csv
```

Scrape one page:
```bash
python scraper.py --pages 1
```

The output CSV is created in the current folder. Open it with Excel, Google Sheets,
or Pandas.

## Dataset fields
- `title`: book title
- `price`: displayed price (GBP)
- `availability`: displayed stock text
- `rating`: star rating as words (One–Five)
- `product_url`: absolute product page URL

## Notes
- This is an educational scraper for a practice website.
- It follows the site's pagination links and pauses between requests.
- Network access may be required; if the site is unavailable, retry later.
- Check website terms and access rules before scraping any other site.
