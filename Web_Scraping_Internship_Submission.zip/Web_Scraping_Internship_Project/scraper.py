"""
Book Data Scraper
Scrapes publicly accessible practice pages from https://books.toscrape.com/
and exports book title, price, availability, rating, and product URL to CSV.
"""
import argparse
import csv
import time
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

BASE_URL = "https://books.toscrape.com/"
HEADERS = {"User-Agent": "EducationalBookScraper/1.0 (learning project)"}

def rating_from_class(classes):
    for item in classes or []:
        if item in {"One", "Two", "Three", "Four", "Five"}:
            return item
    return "Not specified"

def scrape_page(session, url):
    response = session.get(url, timeout=20)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    results = []
    for item in soup.select("article.product_pod"):
        link = item.select_one("h3 a")
        price = item.select_one(".price_color")
        availability = item.select_one(".availability")
        results.append({
            "title": link.get("title", "").strip() if link else "",
            "price": price.get_text(" ", strip=True) if price else "",
            "availability": availability.get_text(" ", strip=True) if availability else "",
            "rating": rating_from_class(item.select_one("p.star-rating").get("class", []))
                      if item.select_one("p.star-rating") else "Not specified",
            "product_url": urljoin(url, link.get("href", "")) if link else "",
        })
    next_link = soup.select_one("li.next a")
    next_url = urljoin(url, next_link.get("href")) if next_link else None
    return results, next_url

def scrape(max_pages=3, delay=1.0):
    if max_pages < 1:
        raise ValueError("--pages must be at least 1")
    session = requests.Session()
    session.headers.update(HEADERS)
    url = BASE_URL
    all_books = []
    page_count = 0
    while url and page_count < max_pages:
        books, next_url = scrape_page(session, url)
        all_books.extend(books)
        page_count += 1
        print(f"Page {page_count}: collected {len(books)} books")
        url = next_url
        if url and page_count < max_pages:
            time.sleep(max(0, delay))
    return all_books

def save_csv(rows, filename):
    fields = ["title", "price", "availability", "rating", "product_url"]
    with open(filename, "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

def main():
    parser = argparse.ArgumentParser(description="Scrape book data for learning.")
    parser.add_argument("--pages", type=int, default=3, help="Maximum pages to scrape (default: 3)")
    parser.add_argument("--delay", type=float, default=1.0, help="Delay between pages in seconds")
    parser.add_argument("--output", default="books_dataset.csv", help="Output CSV filename")
    args = parser.parse_args()
    try:
        rows = scrape(args.pages, args.delay)
        save_csv(rows, args.output)
        print(f"\nSaved {len(rows)} records to {args.output}")
    except requests.RequestException as exc:
        raise SystemExit(f"Network/request error: {exc}")

if __name__ == "__main__":
    main()
