# INTERNSHIP PROJECT REPORT
## Web Scraping Using Python: Book Data Collection

**Submitted by:** Suryansh Bhardwaj  
**Program:** B.Tech, Computer Science  
**Institution:** Sanskriti University, Mathura  
**Internship Task:** Task 1 — Web Scraping  
**Academic Year:** 2026

---

## Abstract
Web scraping is a technique for collecting structured information from web pages. This project presents a Python application that extracts book information from Books to Scrape, a website intended for practicing scraping. The application uses Requests to retrieve HTML pages and BeautifulSoup to parse the page structure. It extracts each book's title, displayed price, availability, star rating, and product URL. It also follows pagination links up to a user-defined page limit and writes the collected records to a CSV file. The resulting dataset can be opened in spreadsheet software or used for further analysis with Python. The project demonstrates the complete basic workflow of data acquisition: requesting pages, inspecting HTML, selecting elements, normalizing fields, handling pagination, and exporting records. It includes error handling for HTTP/network failures and a delay between page requests. The project is educational and intentionally targets a practice website rather than a commercial site. Results depend on the live website and network availability.

## 1. Introduction
Websites often present useful information as HTML intended for display in a browser. For analysis, this information may need to be transformed into rows and columns. Web scraping automates the extraction of selected page elements and converts them into a reusable dataset. Common applications include price monitoring, catalog analysis, research, and public-information collection, subject to applicable access rules.

## 2. Problem Statement
Manually copying book information from multiple pages is repetitive and can introduce transcription errors. The task is to develop a small program that gathers selected book attributes consistently and saves them in a machine-readable format.

## 3. Objectives
1. Understand basic HTML structure and CSS selectors.
2. Retrieve public practice pages with Python Requests.
3. Parse HTML using BeautifulSoup.
4. Extract book title, price, availability, rating, and URL.
5. Navigate multiple pages through pagination links.
6. Export records to CSV for subsequent analysis.
7. Apply basic responsible-scraping practices, including a request delay.

## 4. Scope
The application targets Books to Scrape and extracts the fields listed above. It supports a configurable maximum number of pages and a configurable delay. It does not scrape login-protected pages, bypass access controls, solve CAPTCHAs, or attempt to evade restrictions. The scraper does not guarantee that the website will always be reachable or retain the same HTML structure.

## 5. Tools and Technologies
- **Python:** main programming language.
- **Requests:** sends HTTP requests and receives page content.
- **BeautifulSoup:** parses HTML and selects relevant elements.
- **CSV:** stores tabular output in a portable format.
- **argparse:** accepts command-line options.
- **time:** adds a pause between page requests.

## 6. Methodology
### 6.1 Identify the source
The project uses https://books.toscrape.com/, a practice site designed for learning web scraping.

### 6.2 Retrieve HTML
Requests downloads a page using a session and a descriptive user-agent. The response status is checked so HTTP failures are surfaced.

### 6.3 Parse and extract
BeautifulSoup parses the returned HTML. CSS selectors identify book cards (`article.product_pod`) and their title, price, availability, and rating elements. Relative product links are converted to absolute URLs.

### 6.4 Pagination
The scraper locates the “next” pagination link. It continues until there is no next page or the requested page limit is reached.

### 6.5 Export
The extracted records are written to a UTF-8 CSV file with consistent column names. The file can be opened in Excel or loaded into Pandas.

## 7. System Design
**Input:** maximum page count, delay, output filename.  
**Process:** request page → parse HTML → extract book fields → locate next page → repeat.  
**Output:** CSV dataset and console progress messages.

### Workflow
1. Start program.
2. Read command-line options.
3. Request current page.
4. Check HTTP response.
5. Parse HTML.
6. Extract book records.
7. Find next-page link.
8. Repeat within page limit.
9. Save records to CSV.
10. Display total record count and finish.

## 8. Implementation
The source file `scraper.py` contains:
- `rating_from_class()` to convert rating CSS classes to readable values.
- `scrape_page()` to fetch and parse one page and return its records plus next-page URL.
- `scrape()` to traverse pages up to the limit.
- `save_csv()` to write the dataset.
- `main()` to parse command-line arguments and run the workflow.

The full implementation is included in the accompanying project folder.

## 9. How to Run
1. Install Python 3.9 or later.
2. Open a terminal in the project folder.
3. Create and activate a virtual environment (optional but recommended).
4. Run `pip install -r requirements.txt`.
5. Execute `python scraper.py --pages 3 --output books_dataset.csv`.
6. Open the generated CSV file in a spreadsheet application.

## 10. Dataset Description
Each row represents one book. The dataset contains:
| Column | Description |
|---|---|
| title | Book title |
| price | Price displayed by the website |
| availability | Availability text |
| rating | Rating category from One to Five |
| product_url | Absolute URL for the book page |

The accompanying `sample_books_dataset.csv` is illustrative only; running the scraper creates a fresh dataset from the website.

## 11. Testing and Validation
Recommended checks:
- Run with `--pages 1` and confirm that the CSV is created.
- Verify the CSV header contains all five expected fields.
- Compare a few extracted titles and prices with the corresponding practice page.
- Run with multiple pages and confirm that the console reports page progress.
- Test an unavailable network connection and confirm that a readable request error is shown.

No live scraping result is claimed in this report; the actual record count depends on when and where the script is run.

## 12. Limitations
- The website's HTML structure may change, requiring selector updates.
- Network errors or site downtime can prevent collection.
- The current implementation collects only the fields explicitly listed.
- Prices are retained as displayed strings rather than converted to numeric values.
- The script uses a page limit to control collection size.

## 13. Responsible Use
Scrape only pages you are permitted to access. Review the site's terms, robots guidance, and applicable laws before collecting data from other websites. Use reasonable request rates, avoid collecting personal or sensitive information, and do not bypass authentication or technical restrictions.

## 14. Future Enhancements
- Add data cleaning and numeric price conversion.
- Export to Excel or a database.
- Add logging and retry/backoff for transient failures.
- Add unit tests for HTML parsing using saved sample pages.
- Build charts for price and rating distributions.
- Add a simple dashboard for exploring the collected dataset.

## 15. Conclusion
This project demonstrates a practical end-to-end web scraping workflow with Python. Requests retrieves page content, BeautifulSoup extracts structured book details, pagination expands collection beyond a single page, and CSV export makes the result reusable for analysis. It provides a foundation for more advanced data collection and data-analysis projects while emphasizing responsible access and clear validation.

## References
1. Books to Scrape — https://books.toscrape.com/
2. Requests documentation — https://requests.readthedocs.io/
3. Beautiful Soup documentation — https://www.crummy.com/software/BeautifulSoup/bs4/doc/
4. Python documentation — https://docs.python.org/3/
